package com.org.rest.utilities;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import java.util.Iterator;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.xml.XMLSerializer;

import org.apache.xmlbeans.XmlObject;

/*
 * This class contains the utility methods required for converting XML to JSON and viceversa. 
 */

public class XMLToJSONUtil {

    private static String XML_FORMAT="XML";
    private static String JSON_FORMAT="JSON";
    
    /*
     * Used to convert the XML format to JSON format. Uses json-lib libraries for conversion.
     * The method accepts the XML in string format. The calling BPEL process should convert the 
     * XML payload to string and call this method.
     * 
     * This method will strip all the namespaces and convert XML from string format to JSON format.
     */
    public static String convertXMLToJSON(String xmlString) {
        String jsonStr = null;
        XMLSerializer ser = new XMLSerializer();
 
        ser.clearNamespaces();
        ser.setRemoveNamespacePrefixFromElements(true);
        ser.setSkipNamespaces(true);
        Object res = ser.read(xmlString);

        if (res instanceof JSONArray) {
            JSONArray json = (JSONArray)res;                       
            jsonStr = json.toString(1, 0);            
        } else if (res instanceof JSONObject) {
            JSONObject json = (JSONObject)res;
            jsonStr = json.toString(1, 0);
        }

        return jsonStr;

    }

    /*
     * This method can be used to extract the value for a particular key in JSON string.
     * BPEL or other consumers should call this method by sending the valid JSON string and the
     * token for which we need to extract the value.
     */
    public static String getJSONValue(String jsonStr,String token) {
        JSONObject json = JSONObject.fromObject(jsonStr);  
        Object val = json.get(token);        
        return val.toString();
    }
    
    /*
     * This method returns the JSON string which will created from an Object passed as argument
     */
    public static String objectToJson(Object ob) {
        JSONObject json = JSONObject.fromObject(ob);
        return json.toString(1, 0);
    }
    
    public static String convertToHTTPGetParam(String format, String payload){
        String jsonPayload = null, jsonKey=null, httpGETParams="?";
        
        if(XML_FORMAT.equals(format)){
            jsonPayload = convertXMLToJSON(payload);
        }else if(JSON_FORMAT.equals(format)){
            jsonPayload = payload;
        }else{
            //raise error
            ;
        }
        
        JSONObject json = JSONObject.fromObject(jsonPayload);
        Iterator keyIter = json.keys();
        while(keyIter.hasNext()){
            jsonKey = (String)keyIter.next();            
            httpGETParams += (jsonKey + "=" + json.getString(jsonKey))+"&";                            
        }
        
        return httpGETParams.substring(0, httpGETParams.length()-1);
    }

    public static String convertJSONToXML(String jsonStr) {
        JSONObject json = JSONObject.fromObject(jsonStr); 
        XMLSerializer ser = new XMLSerializer();
        ser.setTypeHintsEnabled(false);
        ser.setTypeHintsCompatibility(false);
        ser.setForceTopLevelObject(false);
        return ser.write(json);        
    }
    
    public static String convertJSONToXML(String jsonStr,String namespace,String rootElement) {
        JSONObject json = JSONObject.fromObject(jsonStr); 
        XMLSerializer ser = new XMLSerializer();
        ser.setTypeHintsEnabled(false);
        ser.setTypeHintsCompatibility(false);
        ser.setForceTopLevelObject(false);
        if(namespace != null){
            //ser.setNamespace("tns", namespace);
            ser.addNamespace(null, namespace);
        }
        if(rootElement != null){
            ser.setRootName(rootElement);
        }
        return ser.write(json);         
    }
}
