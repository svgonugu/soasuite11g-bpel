package com.org.rest.utilities;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import com.oracle.bpel.client.BPELFault;

import java.util.Properties;


public class CallRESTServiceUtil {

    private static String JSON_FORMAT = "JSON";
    private static String HTTP_GET = "GET";
    private static String HTTP_POST = "POST";
    private static String APPL_XML_CTYPE = "application/xml";
    private static int HTTP_TIMEOUT = 10000000;

    /**
     * Invokes GET method on REST based endpoint. This method converts the String converted XML payload to
     * JSON format and send those elements as URL parameters.
     * e.g:
     *      payload sent to this method:
     *              <UserInfo xmlns="http://xmlns.oracle.com/UserInfo">
     *                    <username>st</username>
     *                    <orgname>org1</orgname>
     *                    <password>pwd</password>
     *              </UserInfo>
     *
     *      payload converted to JSON method:
     *              {"username":"st", "orgname":"org1", "password":"pwd" }
     *
     *      URL parameters that would sent
     *               ?username=st&organame=org1&password=pwd
     *
     * @param serviceURL - url of the REST based endpoint
     * @param payload - XML payload converted to String format that has to be sent as URL parameters.
     *                  send value 'null' if no url parameters have to be sent to REST endpoint
     * @param cookie - name, value pair to be used to create the cookies and send in request
     *                 send value 'null' if no cookie has to be sent in the request
     * @return - Response or Error Stream recieved from the URL
     */
    public String invokeGETMethodRESTService(String serviceURL, String payload,
                                             String cookie) {
        HttpURLConnection connection = null;
        OutputStreamWriter wr = null;
        BufferedReader rd = null;
        StringBuilder sb = null;
        String line = null;
        URL serverAddress = null;

        if (payload != null) {
            //convert the string converted XML payload to JSON format
            payload = XMLToJSONUtil.convertXMLToJSON(payload);
            //prepare url parameters from JSON payload and add to service URL to invoke GET method
            serviceURL +=
                    XMLToJSONUtil.convertToHTTPGetParam(JSON_FORMAT, payload);
        }

        try {
            //serviceURL = serviceURL.replaceAll(" +", "%20");           
            serverAddress = new URL(serviceURL);

            //Set up the initial connection
            connection = (HttpURLConnection)serverAddress.openConnection();
            connection.setRequestMethod(HTTP_GET);
            connection.setDoOutput(true);
            connection.setReadTimeout(HTTP_TIMEOUT);
            //create  the cookie only if the value is sent
            if (cookie != null) {
                connection.setRequestProperty("Cookie", cookie);
            }
            connection.connect();

            /* Read the result from the server. Read the response from the error stream if the error code is
             * greater than 400, otherwise read it from input stream.
             */
            if (connection.getResponseCode() >= 400) {
                rd = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
            } else {
                rd = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            }
            sb = new StringBuilder();

            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }

            return (sb.toString());

        } catch (MalformedURLException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (ProtocolException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (IOException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (Exception e) {
            throwBindingFault("Encountered an irrecoverable error.");
        } finally {
            //close the connection, set all objects to null
            connection.disconnect();
            rd = null;
            sb = null;
            wr = null;
            connection = null;
        }
        return "";
    }

   /**
     * Invokes POST method on REST based endpoint. This method converts the String converted XML payload to
     * JSON format and send those elements as payload in HTTP body
     * e.g:
     *      payload sent to this method:
     *              <UserInfo xmlns="http://xmlns.oracle.com/UserInfo">
     *                    <username>st</username>
     *                    <orgname>org1</orgname>
     *                    <password>pwd</password>
     *              </UserInfo>
     *
     *      payload converted to JSON method and sent in body:
     *              {"username":"st", "orgname":"org1", "password":"pwd" }
     *
     * @param serviceURL - url of the REST based endpoint
     * @param payload - XML payload converted to String format that has to be sent as JSON payload
     * @param cookie - name, value pair to be used to create the cookies and send in request
     *                 send value 'null' if no cookie has to be sent in the request
     * @return - Response or Error Stream recieved from the URL
     */
    public String invokePOSTMethodRESTService(String serviceURL,
                                              String payload, String cookie) {
        HttpURLConnection connection = null;
        OutputStreamWriter wr = null;
        OutputStream out = null;
        BufferedReader rd = null;
        StringBuilder sb = null;
        String line = null;

        URL serverAddress = null;

        //get the POST string from the JSON payload
        if (payload != null) {
            //convert the string converted XML payload to JSON format
            payload = XMLToJSONUtil.convertXMLToJSON(payload);
        }

        try {
            //serviceURL = serviceURL.replaceAll(" +", "%20");  
            serverAddress = new URL(serviceURL);

            //Set up the initial connection
            connection = (HttpURLConnection)serverAddress.openConnection();
            connection.setRequestMethod(HTTP_POST);
            connection.setRequestProperty("Content-Type", APPL_XML_CTYPE);
            connection.setRequestProperty("Accept", APPL_XML_CTYPE);
            connection.setDoOutput(true);
            connection.setReadTimeout(HTTP_TIMEOUT);
            //create  the cookie only if the value is sent
            if (cookie != null) {
                connection.setRequestProperty("Cookie", cookie);
            }
            connection.connect();

            //send the payload in HTTP body using outputsream
            if (payload != null) {
                out = connection.getOutputStream();
                out.write(payload.getBytes());
                out.close();
                out.flush();
            }

            /* Read the result from the server. Read the response from the error stream if the error code is
             * greater than 400, otherwise read it from input stream.
             */
            if (connection.getResponseCode() >= 400) {
                rd = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
            } else {
                rd = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            }
            sb = new StringBuilder();

            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }
            return (sb.toString());

        } catch (MalformedURLException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (ProtocolException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (IOException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (Exception e) {
            throwBindingFault("Encountered an irrecoverable error.");
        } finally {
            //close the connection, set all objects to null
            connection.disconnect();
            rd = null;
            sb = null;
            wr = null;
            out = null;
            connection = null;
        }
        return "";
    }

    /**
     * Invokes POST method on REST based endpoint. This method sets the HTTP proxy settings and calls the
     * another overloaded method. This method accepts the string converted XML payload.
     *
     * @param serviceURL - url of the REST based endpoint
     * @param payload - XML payload converted to String format that has to be sent as the HTTP body in JSON format
     * @param cookie - name, value pair to be used to create the cookies and send in request
     *                 send value 'null' if no cookie has to be sent in the request
     * @param httpProxy - HTTP proxy host name
     * @param httpProxyPort - HTTP proxy port
     * @return - Response or Error Stream recieved from the URL
     */
    public String invokePOSTMethodRESTService(String serviceURL,
                                              String payload, String cookie,
                                              String httpProxy,
                                              String httpProxyPort) {
        //set the http proxy settings
        Properties prop = System.getProperties();
        prop.setProperty("http.proxyHost", httpProxy);
        prop.setProperty("http.proxyPort", httpProxyPort);

        return invokePOSTMethodRESTService(serviceURL, payload, cookie);
    }
    
    /**
     * Invokes POST method on REST based endpoint. This method converts the sends the XML payload to to HTTP URL
     * e.g:
     *      payload sent to this method:
     *              <UserInfo xmlns="http://xmlns.oracle.com/UserInfo">
     *                    <username>st</username>
     *                    <orgname>org1</orgname>
     *                    <password>pwd</password>
     *              </UserInfo>
     *
     *
     * @param serviceURL - url of the REST based endpoint
     * @param payload - XML payload converted to String format that has to be sent.
     * @return - Response or Error Stream recieved from the URL
     */
    public String invokePOSTMethodRESTService(String serviceURL,
                                              String payload) {
        HttpURLConnection connection = null;
        OutputStreamWriter wr = null;
        OutputStream out = null;
        BufferedReader rd = null;
        StringBuilder sb = null;
        String line = null;

        URL serverAddress = null;

        try {
            //serviceURL = serviceURL.replaceAll(" +", "%20");  
            serverAddress = new URL(serviceURL);

            //Set up the initial connection
            connection = (HttpURLConnection)serverAddress.openConnection();
            connection.setRequestMethod(HTTP_POST);
            connection.setRequestProperty("Content-Type", APPL_XML_CTYPE);
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setAllowUserInteraction(false);
            connection.setReadTimeout(HTTP_TIMEOUT);
            connection.connect();

            // Write the String to the Output Stream of the Connection
            wr = new OutputStreamWriter(connection.getOutputStream());

            //System.out.println("Writing MAPID to Stream");
            //wr.write("PRODUCT" + "\n");            
            wr.write(payload);            
            wr.flush();            

            /* Read the result from the server. Read the response from the error stream if the error code is
             * greater than 400, otherwise read it from input stream.
             */
            if (connection.getResponseCode() >= 400) {
                rd = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
            } else {
                rd = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            }
            
            sb = new StringBuilder();

            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }
            return (sb.toString());

        } catch (MalformedURLException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (ProtocolException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (IOException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (Exception e) {
            throwBindingFault("Encountered an irrecoverable error.");
        } finally {
            //close the connection, set all objects to null
            connection.disconnect();
            rd = null;
            sb = null;
            wr = null;
            out = null;
            connection = null;
        }
        return "";
    }

    /**Prepares the BPEL Remote Fault and throws from the java code
     * @param errStr - Error string to be used to create the fault
     * @param exception - Original java exception caused this issue.
     */
    public void throwRemoteFault(String errStr, Exception exception) {
        // create a bpel fault
        javax.xml.namespace.QName errorQ =
            new javax.xml.namespace.QName("http://schemas.oracle.com/bpel/extension",
                                          "remoteFault");
        BPELFault fault = new BPELFault(errorQ, errStr);
        fault.initCause(exception);
        throw fault;
    }

    /**Prepares the BPEL Binding Fault and throws from the java code
     * @param errStr - Error string to be used to create the fault
     */
    public void throwBindingFault(String errStr) {
        // create a bpel fault
        javax.xml.namespace.QName errorQ =
            new javax.xml.namespace.QName("http://schemas.oracle.com/bpel/extension",
                                          "bindingFault");
        BPELFault fault = new BPELFault(errorQ, errStr);
        throw fault;
    }

    public static void main(String[] args) {
        String serviceResp, jsonVal, sampleURL = "http://mtrestservice:7001/order";
            String xmlLogin =
                "<UserInfo xmlns=\"http://xmlns.oracle.com\">" +
                "<username>store</username>" + "<orgname>tcc</orgname>" +
                "<password>thestore</password>" + "</UserInfo>";

            String xmlLogin1 =
                "<UserInfo xmlns=\"http://xmlns.oracle.com\">" +
                "<username>tstorep</username>" + "<orgname>HCCSystems</orgname>" +
                "<password>istore45</password>" + "</UserInfo>";

            String xmlCreateOrg =
                "<OrganizationC xmlns=\"http://xmlns.oracle.com\">" +
                "<email>a@a.com</email>" +
                "<orgName>TestOrg8767867676767</orgName>" +
                "<userName>abc</userName>" + "<firstName>bcd</firstName>" +
                "<title>ADEPT PLANT HIRE   (357383)</title>" +
                "<lastName>dcf</lastName>" + "</OrganizationC>";
           
            String posResp =
                "{\"success\":true,\"message\":\"Operation was successful\",\"data\":{\"password\":\"2RE8ZA50O\",\"adminUserName\":\"testorg1admin\",\"success\":true}}";
            String negResp =
                "{\"success\":false,\"message\":\"Failed to create or map new organization[status:false, message:Licensed Organization with name testorg already exists][:]\"}";
            String negResp1 =
                "{\"success\":false,\"messages\":[{\"name\":\"email\",\"message\":\"A value is required for this parameter\"}]}";
          
            try {
                CallRESTServiceUtil callREST = new CallRESTServiceUtil();
                serviceResp =
                        callREST.invokePOSTMethodRESTService(sampleURL,xmlLogin);
                System.out.println("Echo Response: " + serviceResp);
                               
                //get the ticket
                jsonVal = XMLToJSONUtil.getJSONValue(serviceResp, "ticket");
                serviceResp =
                        callREST.invokeGETMethodRESTService("sampleURL",xmlLogin,"ticket=" + jsonVal);
            } catch (Exception e) {
                System.out.println("Entered catch: " + e.getMessage());
            }
        }
}
