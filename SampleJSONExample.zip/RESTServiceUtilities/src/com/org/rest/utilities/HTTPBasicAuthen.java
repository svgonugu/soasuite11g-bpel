package com.org.rest.utilities;

import com.oracle.bpel.client.BPELFault;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import org.apache.xmlbeans.impl.util.Base64;

public class HTTPBasicAuthen {
    static String HTTP_POST = "POST";
    static String APPL_XML_CTYPE = "application/assetId-v1+xml";
    static int HTTP_TIMEOUT = 10000000;

    public String invokePOSTMethodRESTService(String serviceURL,
                                              String payload, String usrName, String passwd) {
        HttpURLConnection connection = null;
        OutputStreamWriter wr = null;
        OutputStream out = null;
        BufferedReader rd = null;
        StringBuilder sb = null;
        String line = null;
        
        URL serverAddress = null;

        try {
            serviceURL = serviceURL.replaceAll(" +", "%20");

            String authString = usrName + ":" + passwd;
            System.out.println("auth string: " + authString);
            
            byte[] authEncBytes = Base64.encode(authString.getBytes());
          
            String authStringEnc = new String(authEncBytes);
            System.out.println("Base64 encoded auth string: " + authStringEnc);

            serverAddress = new URL(serviceURL);

            //Set up the initial connection
            connection = (HttpURLConnection)serverAddress.openConnection();
            //setting http basic authentication
            connection.setRequestProperty("Authorization", "Basic " + authStringEnc);
            
            //connection.se
            
            connection.setRequestMethod(HTTP_POST);
            connection.setRequestProperty("Content-Type", APPL_XML_CTYPE);
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setAllowUserInteraction(false);
            connection.setReadTimeout(HTTP_TIMEOUT);
            connection.connect();

            // Write the String to the Output Stream of the Connection
            wr = new OutputStreamWriter(connection.getOutputStream());

            //System.out.println("Writing MAPID to Stream");
            //wr.write("PRODUCT" + "\n");
            wr.write(payload);
            wr.flush();

            /* Read the result from the server. Read the response from the error stream if the error code is
             * greater than 400, otherwise read it from input stream.
             */
            if (connection.getResponseCode() >= 400) {
                rd =
 new BufferedReader(new InputStreamReader(connection.getErrorStream()));
            } else {
                rd =
 new BufferedReader(new InputStreamReader(connection.getInputStream()));
            }

            sb = new StringBuilder();

            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }
            return (sb.toString());

        } catch (MalformedURLException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (ProtocolException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (IOException e) {
            throwRemoteFault("Unable to invoke the endpoint.", e);
        } catch (Exception e) {
            throwBindingFault("Encountered an irrecoverable error.");
        } finally {
            //close the connection, set all objects to null
            connection.disconnect();
            rd = null;
            sb = null;
            wr = null;
            out = null;
            connection = null;
        }
        return "";
    }
    
    public void throwRemoteFault(String errStr, Exception exception) {
        // create a bpel fault
        javax.xml.namespace.QName errorQ =
            new javax.xml.namespace.QName("http://schemas.oracle.com/bpel/extension",
                                          "remoteFault");
        BPELFault fault = new BPELFault(errorQ, errStr);
        fault.initCause(exception);
        throw fault;
    }

    /**Prepares the BPEL Binding Fault and throws from the java code
     * @param errStr - Error string to be used to create the fault
     */
    public void throwBindingFault(String errStr) {
        // create a bpel fault
        javax.xml.namespace.QName errorQ =
            new javax.xml.namespace.QName("http://schemas.oracle.com/bpel/extension",
                                          "bindingFault");
        BPELFault fault = new BPELFault(errorQ, errStr);
        throw fault;
    }

    public static void main(String[] args) {
        String serviceResp, jsonVal, sampleURL =
            "http://ihub2.trimble.com:922/cds/rest/ed/assetid/E140/111/CAT/B9N00209";
        String xmlLogin = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                          "<tns:AssetId xmlns:tns=\"http://www.cat.com/equipmentData/assetId-v1\""+
                          "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""+
                          "xsi:schemaLocation=\"http://www.cat.com/equipmentData/assetId-v1 assetId-v1.xsd\">"+
                          "<tns:nickname>Ol Bessie</tns:nickname> </tns:AssetId>";
      

        try {
            HTTPBasicAuthen callREST = new HTTPBasicAuthen();
            serviceResp =
                    callREST.invokePOSTMethodRESTService(sampleURL, xmlLogin,"username","pwd");
            System.out.println("Service Response: " + serviceResp);

        } catch (Exception e) {
            System.out.println("Entered catch: " + e.getMessage());
        }
    }

}
