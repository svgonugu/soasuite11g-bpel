package com.trimble.bpel;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;


public class RESTServiceCallImpl {

    public String ValidateOrgName(String serviceURL,String orgName) {
        System.out.println("Entered ValidateOrgName");
        return extractFromJSON(invokeValidateOrgService(serviceURL, orgName, null));

    }

   /* private static String ValidateOrgNameServiceURL =
        "http://waf-dev.am.trimblecorp.net:916/app/tcc/tccManager/actions/ValidateOrgName";*/

    private static String extractFromJSON(String response) {
        System.out.println(response);
        System.out.println("Entered extractFromJSON");
        final JSONObject jsonObj = (JSONObject)JSONValue.parse(response);
        //System.out.println(jsonObj);
        String ValidateOrgNameMessage = null;

        if (jsonObj != null && jsonObj.containsKey("success")) {
            //final JSONObject successData = (JSONObject)jsonObj.get("success");
            boolean successMessage = (Boolean)jsonObj.get("success");
            String messageData = (String)jsonObj.get("message");
            ValidateOrgNameMessage = messageData.toString();
            System.out.println("ValidateOrgNameMessage=..." +
                               ValidateOrgNameMessage);

        }
        return ValidateOrgNameMessage;
    }

    private static String invokeValidateOrgService(String serviceURL,String orgnameinp, String ticketID) {
        HttpURLConnection connection = null;
        OutputStreamWriter wr = null;
        BufferedReader rd = null;
        StringBuilder sb = null;
        String line = null;
        
        URL serverAddress = null;

        try {
            serverAddress =
                    new URL(serviceURL + "?orgName=" + orgnameinp +
                            "&ticket=" + "TICKET_8a8b64be64bc23d869f1cf0c8ef7cb41b0616fdd");
            //set up out communications stuff
            connection = null;

            //Set up the initial connection
            connection = (HttpURLConnection)serverAddress.openConnection();
            connection.setRequestMethod("GET");

            connection.setDoOutput(true);
            connection.setReadTimeout(10000);

            connection.connect();
            System.out.println("Entered validateOrgName");
            
            //read the result from the server
            rd =  new BufferedReader(new InputStreamReader(connection.getInputStream()));
            sb = new StringBuilder();

            while ((line = rd.readLine()) != null) {
                sb.append(line);
            }

            return (sb.toString());
            
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            //close the connection, set all objects to null
            connection.disconnect();
            rd = null;
            sb = null;
            wr = null;
            connection = null;
        }
        return null;
    }


   /* public static void main(String[] args) {

        try {
            RESTServiceCallImpl vOrgNameImpl = new RESTServiceCallImpl();
            System.out.println("Entered main");
            String name =
                vOrgNameImpl.ValidateOrgName("Scott123", "TICKET_8a8b64be64bc23d869f1cf0c8ef7cb41b0616fdd");
            System.out.println(name);
        } catch (Exception e) {
            System.out.println("Entered catch");
            System.out.println(e.getMessage());
        }

    }*/
}
