package com.trimble.bpel;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.xml.XMLSerializer;

import org.apache.xmlbeans.XmlObject;


public class XMLToJSON {

    public static String convertXMLToJSON(String xmlString) {

        XMLSerializer ser = new XMLSerializer();
        ser.clearNamespaces();
        ser.setRemoveNamespacePrefixFromElements(true);
        ser.setSkipNamespaces(true);

        Object res = ser.read(xmlString);

        if (res instanceof JSONArray) {
            JSONArray json = (JSONArray)res;
            //json = convert(json,type);
            System.out.println(json.toString(1, 0));

            return json.toString(1, 0);
        } else if (res instanceof JSONObject) {
            JSONObject json = (JSONObject)res;
            // json = convert(json,type);
            System.out.println(" json object string: " + json.toString(1, 0));

            return json.toString(1, 0);
        }

        return "";

    }


    public String objectToJson(Object ob) {
        JSONObject json = JSONObject.fromObject(ob);
        return json.toString(1, 0);
    }

    private static void invoke(Object inst, Method m, JSONObject obj) {
        try {
            m.invoke(inst, new Object[] { obj });
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    private static JSONObject convert(JSONObject json, String type) {

        Class dynamicConvertorClass = null;
        Object clazzInst = null;
        Method m = null;
        try {
            dynamicConvertorClass =
                    Class.forName("nl.whitehorses.json.convertor." +
                                  type.substring(0, 1).toUpperCase() +
                                  type.substring(1).toLowerCase());
            clazzInst = dynamicConvertorClass.newInstance();
            m =
  dynamicConvertorClass.getMethod("changeType", new Class[] { JSONObject.class });
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
        invoke(clazzInst, m, json);

        return json;
    }


    public static String xmlToJson(XmlObject xml, String type, String output) {
        if (type.indexOf("/") > 0) {
            type = type.substring(0, type.indexOf("/"));
        }

        System.out.println("type " + type);
        System.out.println("content " + xml.xmlText());

        if (output.equalsIgnoreCase("output=json")) {

            if (!type.equalsIgnoreCase("not")) {
                XMLSerializer ser = new XMLSerializer();
                Object res = ser.read(xml.xmlText());
                if (res instanceof JSONArray) {
                    JSONArray json = (JSONArray)res;
                    //json = convert(json, type);
                    return json.toString(1, 0);
                }
                if (res instanceof JSONObject) {
                    JSONObject json = (JSONObject)res;
                    //json = convert(json, type);
                    return json.toString(1, 0);
                }
            }
        }
        return xml.xmlText();
    }

}
