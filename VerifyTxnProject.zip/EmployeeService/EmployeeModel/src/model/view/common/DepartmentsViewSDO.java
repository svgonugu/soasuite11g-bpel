package model.view.common;

public interface DepartmentsViewSDO {

   public java.lang.Integer getDepartmentId();

   public void setDepartmentId(java.lang.Integer value);

   public java.lang.String getDepartmentName();

   public void setDepartmentName(java.lang.String value);

   public java.lang.Integer getManagerId();

   public void setManagerId(java.lang.Integer value);

   public java.lang.Integer getLocationId();

   public void setLocationId(java.lang.Integer value);


}

